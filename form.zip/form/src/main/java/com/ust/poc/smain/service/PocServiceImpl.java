package com.ust.poc.smain.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.poc.smain.dao.PocDao;
import com.ust.poc.smain.model.Model;

@Service
public class PocServiceImpl implements PocService{
	
	@Autowired
	PocDao PDao;

	@Override
	public Model addUser(Model model) {
		return PDao.addUsers(model);
	}

	@Override
	public List<Model> displayUser() {
		return PDao.displayUsers();
	}

	@Override
	public String deleteUser(int id) {
		return PDao.deleteUsers(id);
	}

	@Override
	public Model searchUser(int id) {
		return PDao.searchUsers(id);
	}

}
