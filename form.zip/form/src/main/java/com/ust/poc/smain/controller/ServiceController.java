package com.ust.poc.smain.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.poc.smain.model.Model;
import com.ust.poc.smain.service.PocService;

@RestController
public class ServiceController {
	@Autowired
	PocService pService;

	//test
	
	@RequestMapping("hi")
	@GetMapping

	public String hello()
	{
		return "hello world";
	}
	
	// Add User
	@RequestMapping("add")
	@PostMapping
	public Model addUsers(@RequestBody Model model) {

		return pService.addUser(model);

		
	}

	// List all User
	@RequestMapping("display")
	@GetMapping
	public List<Model> getallUser() {
		return pService.displayUser();
	}

	// Search a particular User using id
	@RequestMapping("search")
	@PostMapping
	public Model searchEmp(@RequestBody int id) {

		return pService.searchUser(id);

	}

	// Delete a employee using id
	@RequestMapping("delete")
	@PostMapping
	public String deleteUsers(@RequestBody int id) {

		return pService.deleteUser(id);
	}

}
