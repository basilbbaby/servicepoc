package com.ust.poc.smain.service;

import java.util.List;

import com.ust.poc.smain.model.Model;


public interface PocService {
	
	public Model addUser(Model model);
	public List<Model> displayUser();
	public String deleteUser(int id);
	public Model searchUser(int id);
}
