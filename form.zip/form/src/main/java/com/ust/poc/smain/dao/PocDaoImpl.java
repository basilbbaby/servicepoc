package com.ust.poc.smain.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ust.poc.smain.model.Model;

@Repository
public class PocDaoImpl implements PocDao {

	@Autowired
	SessionFactory SessionFactory;

	public SessionFactory getSessionFactory() {
		return SessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		SessionFactory = sessionFactory;
	}

	@Override
	public Model addUsers(Model model) {

		if (model.getHcId() != 0) {
			try {

				// ------------To check the YYYY count--------------
				String date1 = model.getDob();
				String[] dateCheker = date1.split("-");
				String year = dateCheker[0];
				// --------------------------
				if (year.length() == 4) {
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					format.setLenient(false);
					Date date2 = format.parse(date1);
					Date date = new Date();
					// -------To check the current date------
					if (!(date2.after(date))) {
						Session session = SessionFactory.openSession();
						session.beginTransaction();
						session.save(model);
						session.getTransaction().commit();
						return model;
					} else {
						model.setError("Date format error, the date is after the current date");
						return model;
					}
				} else {
					model.setError("Date format error, requried format is (yyyy-MM-dd)");
					return model;
				}

			} catch (ParseException e2) {
				model.setError(" Date format error, requried format is (yyyy-MM-dd)");
				return model;
			}
		} else {
			model.setError("hcId is mandatory and can't be empty");
			return model;

		}
	}

	@Override
	public List<Model> displayUsers() {

		Session session = SessionFactory.openSession();
		Query query = session.createQuery("from Model");
		List<Model> models = query.list();
		return models;
	}

	@Override
	public String deleteUsers(int id) {
		Session session = SessionFactory.openSession();
		session.beginTransaction();
		Model model = session.get(Model.class, id);

		if (model == null) {

			return " hcId " + id + " not found, please try again!";
		}
		session.delete(model);
		session.getTransaction().commit();
		return " hcId " + id + " deleted successfully";
	}

	@Override
	public Model searchUsers(int id) {
		Model model1 = new Model();
		Session session = SessionFactory.openSession();
		Query query = session.createQuery("from Model where hcId=" + id);
		Model model = (Model) query.uniqueResult();

		if (model == null) {

			model1.setError(" hcId " + id + " not found, please try again!");
			return model1;
		}
		return model;
	}
}
