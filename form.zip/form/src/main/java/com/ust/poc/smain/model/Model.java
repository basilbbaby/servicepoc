package com.ust.poc.smain.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@JsonInclude(Include.NON_NULL)
public class Model {

	@Id
	@NotNull
	int hcId;
	String fName;
	String lName;
	//@Temporal(TemporalType.DATE)
	// @DateTimeFormat(pattern="yyyy-MM-dd")
	String dob;
	//String dob;
	String error;

	public Model(int hcId, String fName, String lName, String dob) {
		super();
		this.hcId = hcId;
		this.fName = fName;
		this.lName = lName;
		this.dob = dob;
	}

	public Model() {
		super();
	}

	public int getHcId() {
		return hcId;
	}

	public void setHcId(int hcId) {
		this.hcId = hcId;
	}

	public String getfName() {
		return fName;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
